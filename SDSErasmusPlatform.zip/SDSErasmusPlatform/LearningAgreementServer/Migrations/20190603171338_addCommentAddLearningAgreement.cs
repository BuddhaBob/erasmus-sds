﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace LearningAgreementServer.Migrations
{
    public partial class addCommentAddLearningAgreement : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Courses_Faculties_CoursesId",
                table: "Courses");

            migrationBuilder.RenameColumn(
                name: "CoursesId",
                table: "Courses",
                newName: "FacultyId");

            migrationBuilder.RenameIndex(
                name: "IX_Courses_CoursesId",
                table: "Courses",
                newName: "IX_Courses_FacultyId");

            migrationBuilder.CreateTable(
                name: "Comments",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Text = table.Column<string>(nullable: true),
                    NameUser = table.Column<string>(nullable: true),
                    Title = table.Column<string>(nullable: true),
                    CourseAssociated = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Comments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "LearningAgreements",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Seed = table.Column<string>(nullable: true),
                    LearningAgreementFile = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LearningAgreements", x => x.Id);
                });

            migrationBuilder.AddForeignKey(
                name: "FK_Courses_Faculties_FacultyId",
                table: "Courses",
                column: "FacultyId",
                principalTable: "Faculties",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Courses_Faculties_FacultyId",
                table: "Courses");

            migrationBuilder.DropTable(
                name: "Comments");

            migrationBuilder.DropTable(
                name: "LearningAgreements");

            migrationBuilder.RenameColumn(
                name: "FacultyId",
                table: "Courses",
                newName: "CoursesId");

            migrationBuilder.RenameIndex(
                name: "IX_Courses_FacultyId",
                table: "Courses",
                newName: "IX_Courses_CoursesId");

            migrationBuilder.AddForeignKey(
                name: "FK_Courses_Faculties_CoursesId",
                table: "Courses",
                column: "CoursesId",
                principalTable: "Faculties",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
