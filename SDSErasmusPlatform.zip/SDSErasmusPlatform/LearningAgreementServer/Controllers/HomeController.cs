﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LearningAgreementServer.Models;

namespace LearningAgreementServer.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult SelectHomeUniversity()
        {
            return View();
        }


        public IActionResult StudentIncoming()
        {
            return View();
        }

        public IActionResult StudentOutgoing()
        {
            return View();
        }

        public IActionResult SendingInstitutionIncoming()
        {
            try
            {
                string data = Request.Form["name"] + "&&" + Request.Form["surname"] + "&&" +
                Request.Form["nationality"] + "&&" + Request.Form["stcycle"] + "&&" +
                Request.Form["email"] + "&&" + Request.Form["fieldOfEducation"] + "&&" +
                Request.Form["date"] + "&&" + Request.Form["gender"];
                ViewData["data"] = data;
            } catch (Exception) 
            {
                ViewData["data"] = "";
            }

            return View();
        }

        public IActionResult SendingInstitutionOutgoing()
        {
            try
            {
                string data = Request.Form["name"] + "&&" + Request.Form["surname"] + "&&" +
                Request.Form["nationality"] + "&&" + Request.Form["stcycle"] + "&&" +
                Request.Form["email"] + "&&" + Request.Form["fieldOfEducation"] + "&&" +
                Request.Form["date"] + "&&" + Request.Form["gender"];
                ViewData["data"] = data;
            }
            catch (Exception)
            {
                ViewData["data"] = "";
            }

            return View();
        }

        public IActionResult ReceivingInstitutionIncoming()
        {
            try
            {
                string data = Request.Form["data"] + "&&" + Request.Form["name"] + "&&" +
                Request.Form["faculty"] + "&&" + Request.Form["code"] + "&&" +
                Request.Form["address"] + "&&" + Request.Form["country"] + "&&" +
                Request.Form["contactName"] + "&&" + Request.Form["contactEmail"] + "&&" +
                Request.Form["contactPhone"];
                ViewData["data"] = data;
            } catch (Exception)
            {
                ViewData["data"] = "";
            }

            return View();
        }

        public IActionResult ReceivingInstitutionOutgoing()
        {
            try
            {
                string data = Request.Form["data"] + "&&" + Request.Form["faculty"];

                ViewData["data"] = data;
            }
            catch (Exception)
            {
                ViewData["data"] = "";
            }

            return View();
        }

        public IActionResult BeforeTheMobilityOutgoing(string action)
        {
            try
            {
                string data = "";
                string from = "";
                string to = "";
                string langLev = "";
                string language = "";
                string catalogue = "";
                string provisions = "";
                string recCourses = "";
                string senCourses = "";
                bool addSending = false;
                bool addReceiving = false;


                if (action.Equals("Add Receiving Course"))
                {
                    data = Request.Form["data"];
                    from = Request.Form["from"];
                    to = Request.Form["to"];
                    langLev = Request.Form["langLev"];
                    language = Request.Form["language"];
                    catalogue = Request.Form["catalogue"];
                    provisions= Request.Form["provisions"];
                    recCourses = Request.Form["recCourses"];
                    senCourses = Request.Form["senCourses"];
                    addReceiving = true;

                }
                else if(action.Equals("Add Sending Course"))
                {
                    data = Request.Form["data"];
                    from = Request.Form["from"];
                    to = Request.Form["to"];
                    langLev = Request.Form["langLev"];
                    language = Request.Form["language"];
                    catalogue = Request.Form["catalogue"];
                    provisions = Request.Form["provisions"];
                    recCourses = Request.Form["recCourses"];
                    senCourses = Request.Form["senCourses"];
                    addSending = true;

                }
                else if(action.Equals("Confirm Sending Course"))
                {
                    data = Request.Form["data"];
                    from = Request.Form["from"];
                    to = Request.Form["to"];
                    langLev = Request.Form["langLev"];
                    language = Request.Form["language"];
                    catalogue = Request.Form["catalogue"];
                    provisions = Request.Form["provisions"];
                    recCourses = Request.Form["recCourses"];
                    if (Request.Form["senCourses"].ToString().Equals(""))
                    {
                        senCourses = Request.Form["newSenCode"] + "***" + 
                            Request.Form["newSenName"] + "***" + 
                            Request.Form["newSenSemester"] + "***" + 
                            Request.Form["newSenEcts"];
                    }
                    else
                    {
                        senCourses = Request.Form["senCourses"] + ";;" +
                           Request.Form["newSenCode"] + "***" +
                           Request.Form["newSenName"] + "***" +
                           Request.Form["newSenSemester"] + "***" +
                           Request.Form["newSenEcts"];
                    }
                }
                else if (action.Equals("Confirm Receiving Course"))
                {
                    data = Request.Form["data"];
                    from = Request.Form["from"];
                    to = Request.Form["to"];
                    langLev = Request.Form["langLev"];
                    language = Request.Form["language"];
                    catalogue = Request.Form["catalogue"];
                    provisions = Request.Form["provisions"];
                    senCourses = Request.Form["senCourses"];
                    if (Request.Form["recCourses"].ToString().Equals(""))
                    {
                        recCourses = Request.Form["newRecCode"] + "***" +
                            Request.Form["newRecName"] + "***" +
                            Request.Form["newRecSemester"] + "***" +
                            Request.Form["newRecEcts"];
                    }
                    else
                    {
                        recCourses = Request.Form["recCourses"] + ";;" +
                           Request.Form["newRecCode"] + "***" +
                           Request.Form["newRecName"] + "***" +
                           Request.Form["newRecSemester"] + "***" +
                           Request.Form["newRecEcts"];
                    }
                }
                else
                {
                    data = Request.Form["data"] + "&&" + Request.Form["name"] + "&&" +
                        Request.Form["faculty"] + "&&" + Request.Form["code"] + "&&" +
                        Request.Form["address"] + "&&" + Request.Form["country"] + "&&" +
                        Request.Form["contactName"] + "&&" + Request.Form["contactEmail"] + "&&" +
                        Request.Form["contactPhone"];
                }
                ViewData["data"] = data;
                ViewData["from"] = from;
                ViewData["to"] = to;
                ViewData["langLev"] = langLev;
                ViewData["language"] = language;
                ViewData["catalogue"] = catalogue;
                ViewData["provisions"] = provisions;
                ViewData["recCourses"] = recCourses;
                ViewData["senCourses"] = senCourses;
                ViewData["addSending"] = addSending;
                ViewData["addReceiving"] = addReceiving;

            } catch(Exception)
            {
                ViewData["data"] = "";
                ViewData["senCourses"] = "";
                ViewData["addReceiving"] = false;
                ViewData["addSending"] = false;

            }

            return View();
        }

        public IActionResult BeforeTheMobilityIncoming(string action)
        {
            try
            {
                string data = "";
                string from = "";
                string to = "";
                string langLev = "";
                string language = "";
                string catalogue = "";
                string provisions = "";
                string recCourses = "";
                string senCourses = "";
                bool add = false;
                List<Course> courses = new List<Course>();


                if (action.Equals("Add course"))
                {
                    data = Request.Form["data"];
                    from = Request.Form["from"];
                    to = Request.Form["to"];
                    langLev = Request.Form["langLev"];
                    language = Request.Form["language"];
                    catalogue = Request.Form["catalogue"];
                    provisions = Request.Form["provisions"];
                    senCourses = Request.Form["senCourses"];
                    if (Request.Form["recCourses"].ToString().Equals(""))
                    {
                        recCourses = Request.Form["courseAdd"];
                    }
                    else
                        recCourses = Request.Form["recCourses"] + ";;" + Request.Form["courseAdd"];
                    using (var db = new LearningAgreementContext())
                    {
                        foreach (string s in recCourses.Split(";;"))
                        {
                            var query =
                            (from Course in db.Courses
                             where Course.Course_name.Equals(s)
                             select Course);
                            Course c = query.First();
                            courses.Add(query.First());
                        }
                    }
                }
                else if (action.Equals("Add Empty Course"))
                {
                    data = Request.Form["data"];
                    from = Request.Form["from"];
                    to = Request.Form["to"];
                    langLev = Request.Form["langLev"];
                    language = Request.Form["language"];
                    catalogue = Request.Form["catalogue"];
                    provisions = Request.Form["provisions"];
                    recCourses = Request.Form["recCourses"];
                    senCourses = Request.Form["senCourses"];
                    add = true;
                    using (var db = new LearningAgreementContext())
                    {
                        foreach (string s in recCourses.Split(";;"))
                        {
                            var query =
                            (from Course in db.Courses
                             where Course.Course_name.Equals(s)
                             select Course);
                            Course c = query.First();
                            courses.Add(query.First());
                        }
                    }
                }
                else if (action.Equals("Confirm"))
                {
                    data = Request.Form["data"];
                    from = Request.Form["from"];
                    to = Request.Form["to"];
                    langLev = Request.Form["langLev"];
                    language = Request.Form["language"];
                    catalogue = Request.Form["catalogue"];
                    provisions = Request.Form["provisions"];
                    recCourses = Request.Form["recCourses"];
                    if (Request.Form["senCourses"].ToString().Equals(""))
                    {
                        senCourses = Request.Form["newCode"] + "***" +
                            Request.Form["newName"] + "***" +
                            Request.Form["newSemester"] + "***" +
                            Request.Form["newEcts"];
                    }
                    else
                    {
                        senCourses = Request.Form["senCourses"] + ";;" +
                           Request.Form["newCode"] + "***" +
                           Request.Form["newName"] + "***" +
                           Request.Form["newSemester"] + "***" +
                           Request.Form["newEcts"];
                    }
                    using (var db = new LearningAgreementContext())
                    {
                        foreach (string s in recCourses.Split(";;"))
                        {
                            var query =
                            (from Course in db.Courses
                             where Course.Course_name.Equals(s)
                             select Course);
                            Course c = query.First();
                            courses.Add(query.First());
                        }
                    }
                }
                else
                {
                    data = Request.Form["data"] + "&&" + Request.Form["faculty"];
                }
                ViewData["data"] = data;
                ViewData["from"] = from;
                ViewData["to"] = to;
                ViewData["langLev"] = langLev;
                ViewData["language"] = language;
                ViewData["catalogue"] = catalogue;
                ViewData["provisions"] = provisions;
                ViewData["recCourses"] = recCourses;
                ViewData["senCourses"] = senCourses;
                ViewData["add"] = add;
                ViewBag.List = courses;
            }
            catch (Exception)
            {
                ViewData["data"] = "";
                ViewData["senCourses"] = "";
                ViewData["add"] = false;
                ViewBag.List = new List<Course>();

            }

            return View();
        }

        public IActionResult CommitmentIncoming()
        {
            try
            {
                string data = Request.Form["data"] + "&&" + Request.Form["from"] + "&&" +
                Request.Form["to"] + "&&" + Request.Form["recCourses"] + "&&" +
                Request.Form["language"] + "&&" + Request.Form["langLev"] + "&&" +
                Request.Form["catalogue"] + "&&" + Request.Form["senCourses"] + "&&" +
                Request.Form["provisions"];
                ViewData["data"] = data;
            }
            catch (Exception)
            {
                ViewData["data"] = "";
            }

            return View();
        }

        public IActionResult CommitmentOutgoing()
        {
            try
            {
                string data = Request.Form["data"] + "&&" + Request.Form["from"] + "&&" +
                Request.Form["to"] + "&&" + Request.Form["recCourses"] + "&&" +
                Request.Form["language"] + "&&" + Request.Form["langLev"] + "&&" +
                Request.Form["catalogue"] + "&&" + Request.Form["senCourses"] + "&&" +
                Request.Form["provisions"];
                ViewData["data"] = data;
            }
            catch (Exception)
            {
                ViewData["data"] = "";
            }

            return View();
        }

        public IActionResult LearningAgreementIncoming()
        {
            try
            {
                string data = Request.Form["data"].ToString();
                ViewData["nameS"] = Request.Form["nameS"].ToString();
                ViewData["emailS"] = Request.Form["emailS"].ToString();
                ViewData["positionS"] = Request.Form["positionS"].ToString();
                ViewData["nameR"] = Request.Form["nameR"].ToString();
                ViewData["emailR"] = Request.Form["emailR"].ToString();
                ViewData["positionR"] = Request.Form["positionR"].ToString();

                string[] group = data.Split("&&");

                ViewData["nameSt"] = group[0];
                ViewData["surnameSt"] = group[1];
                ViewData["nationality"] = group[2];
                ViewData["stCicle"] = group[3];
                ViewData["emailSt"] = group[4];
                ViewData["fieldOfEducation"] = group[5];
                ViewData["birthDay"] = group[6];
                ViewData["gender"] = group[7];

                ViewData["sendUniName"] = group[8];
                ViewData["sendFacName"] = group[9];
                ViewData["sendUniCode"] = group[10];
                ViewData["sendFacAddress"] = group[11];
                ViewData["sendUniCountry"] = group[12];
                ViewData["sendUniContactName"] = group[13];
                ViewData["sendUniContactEmail"] = group[14];
                ViewData["sendUniContactPhone"] = group[15];

                ViewData["recFacName"] = group[16];

                ViewData["from"] = group[17];
                ViewData["to"] = group[18];
                ViewData["recCourses"] = group[19];
                ViewData["language"] = group[20];
                ViewData["langLev"] = group[21];
                ViewData["catalogue"] = group[22];
                ViewData["senCourses"] = group[23];
                ViewData["provisions"] = group[24];

                List<Course> courses = new List<Course>();

                using (var db = new LearningAgreementContext())
                {
                    var query =
                        (from Faculty in db.Faculties
                         where Faculty.Faculty_name.Equals(@group[16])
                         select Faculty.Address);
                    ViewData["recFacAddress"] = query.First();

                    foreach (string s in group[19].Split(";;"))
                    {
                        var query2 =
                        (from Course in db.Courses
                         where Course.Course_name.Equals(s)
                         select Course);
                        Course c = query2.First();
                        courses.Add(query2.First());
                    }
                }
                ViewBag.List = courses;

                if (!group[17].Equals(""))
                {
                    DateTime d = Convert.ToDateTime(group[17]);
                    if (d.Month > 6)
                    {
                        ViewData["academicYear"] = $"{d.Year}/{d.Year + 1}";
                    }
                    else
                    {
                        ViewData["academicYear"] = $"{d.Year - 1}/{d.Year}";
                    }
                }
            }
            catch (Exception)
            {
                ViewData["data"] = "";
                ViewData["senCourses"] = "";
                ViewBag.List = new List<Course>();

            }

            return View();
        }

        public IActionResult LearningAgreementOutgoing()
        {
            try
            {
                string data = Request.Form["data"].ToString();
                ViewData["nameS"] = Request.Form["nameS"].ToString();
                ViewData["emailS"] = Request.Form["emailS"].ToString();
                ViewData["positionS"] = Request.Form["positionS"].ToString();
                ViewData["nameR"] = Request.Form["nameR"].ToString();
                ViewData["emailR"] = Request.Form["emailR"].ToString();
                ViewData["positionR"] = Request.Form["positionR"].ToString();

                string[] group = data.Split("&&");

                ViewData["nameSt"] = group[0];
                ViewData["surnameSt"] = group[1];
                ViewData["nationality"] = group[2];
                ViewData["stCicle"] = group[3];
                ViewData["emailSt"] = group[4];
                ViewData["fieldOfEducation"] = group[5];
                ViewData["birthDay"] = group[6];
                ViewData["gender"] = group[7];

                ViewData["senFacName"] = group[8];

                ViewData["recUniName"] = group[9];
                ViewData["recFacName"] = group[10];
                ViewData["recUniCode"] = group[11];
                ViewData["recFacAddress"] = group[12];
                ViewData["recUniCountry"] = group[13];
                ViewData["recUniContactName"] = group[14];
                ViewData["recUniContactEmail"] = group[15];
                ViewData["recUniContactPhone"] = group[16];

                ViewData["from"] = group[17];
                ViewData["to"] = group[18];
                ViewData["recCourses"] = group[19];
                ViewData["language"] = group[20];
                ViewData["langLev"] = group[21];
                ViewData["catalogue"] = group[22];
                ViewData["senCourses"] = group[23];
                ViewData["provisions"] = group[24];
                
                using (var db = new LearningAgreementContext())
                {
                    var query =
                        (from Faculty in db.Faculties
                         where Faculty.Faculty_name.Equals(@group[8])
                         select Faculty.Address);
                    ViewData["senFacAddress"] = query.First();
                }

                if (!group[17].Equals(""))
                {
                    DateTime d = Convert.ToDateTime(group[17]);
                    if (d.Month > 6)
                    {
                        ViewData["academicYear"] = $"{d.Year}/{d.Year + 1}";
                    }
                    else
                    {
                        ViewData["academicYear"] = $"{d.Year - 1}/{d.Year}";
                    }
                }

            }
            catch (Exception)
            {
                ViewData["data"] = "";
                ViewData["senCourses"] = "";

            }

            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
