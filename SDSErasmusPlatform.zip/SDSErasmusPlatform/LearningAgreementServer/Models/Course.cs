﻿using System.Collections.Generic;
namespace LearningAgreementServer.Models
{
    public class Course
    {
        public int Id { get; set; }

        public string Course_name { get; set; }
        public int Ects { get; set; }
        public string Description { get; set; }
        public string Semester { get; set; }
        public Faculty Faculty { get; set; }
    }
}
