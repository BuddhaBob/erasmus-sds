﻿using System.Collections.Generic;
namespace LearningAgreementServer.Models
{
    public class LearningAgreement
    {
        public int Id { get; set; }

        public string Seed { get; set; }
        public string LearningAgreementFile { get; set; }
    }
}
