﻿using Microsoft.EntityFrameworkCore;
namespace LearningAgreementServer.Models
{
    public class LearningAgreementContext : DbContext
    {
        public DbSet<Course> Courses { get; set; }
        public DbSet<Faculty> Faculties { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=erasmusDatabase.db");
        }
    }
}
