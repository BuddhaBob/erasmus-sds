﻿using Microsoft.EntityFrameworkCore;
namespace LearningAgreementServer.Models
{
    public class LearningAgreementContext : DbContext
    {
        public DbSet<Course> Courses { get; set; }
        public DbSet<Faculty> Faculties { get; set; }
        public DbSet<LearningAgreement> LearningAgreements { get; set; }
        public DbSet<Comment> Comments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=erasmusDatabase.db");
        }
    }
}
