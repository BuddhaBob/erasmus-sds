﻿using System.Collections.Generic;
namespace LearningAgreementServer.Models
{
    public class Faculty
    {
        public int Id { get; set; }

        public string Faculty_name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public ICollection<Course> Courses { get; set; }
    }
}
